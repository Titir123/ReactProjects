import Wrapper from "@/layout/wrapper/Wrapper";
import "@/styles/globals.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/globals.css';
import "../styles/carousel.css";


const queryClient = new QueryClient();

export default function App({ Component, pageProps }) {
    return (
        <div>
            <QueryClientProvider client={queryClient}>
                <Wrapper>
                    <Component {...pageProps} />
                    <ToastContainer />
                </Wrapper>
                
            </QueryClientProvider>
        </div>
    );
}

import { profile_pic } from '@/api/axios/axios';
import { useGetProfileQueries } from '@/hooks/customHooks/cmsQuery.hooks';
import React from 'react'


export default function index() {

    const {data, isError, isLoading} = useGetProfileQueries();
    if (isLoading) return <p>Loading...</p>;
    if (isError) return <p>Error loading products</p>;

  return (
    <>
     <img style={{width:"100px", height:"100px"}} src={profile_pic(data.profile_pic)} alt="" />
     <h4>{data?.first_name}</h4>
     <h4>{data?.last_name}</h4>
     <h4>{data?.email}</h4>
    </>
  )
}

/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js":
/*!******************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Box: () => (/* reexport default from dynamic */ _Box__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Container: () => (/* reexport default from dynamic */ _Container__WEBPACK_IMPORTED_MODULE_1___default.a),\n/* harmony export */   Grid: () => (/* reexport default from dynamic */ _Grid__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   IconButton: () => (/* reexport default from dynamic */ _IconButton__WEBPACK_IMPORTED_MODULE_3___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_4___default.a)\n/* harmony export */ });\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Box */ \"./node_modules/@mui/material/node/Box/index.js\");\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Box__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/@mui/material/node/Container/index.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Container__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Grid */ \"./node_modules/@mui/material/node/Grid/index.js\");\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Grid__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./IconButton */ \"./node_modules/@mui/material/node/IconButton/index.js\");\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_IconButton__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1Cb3gsQ29udGFpbmVyLEdyaWQsSWNvbkJ1dHRvbixUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ3NDO0FBQ1k7QUFDVjtBQUNZIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dHByb2plY3QvLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcz9mODhlIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCb3ggfSBmcm9tIFwiLi9Cb3hcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb250YWluZXIgfSBmcm9tIFwiLi9Db250YWluZXJcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBHcmlkIH0gZnJvbSBcIi4vR3JpZFwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEljb25CdXR0b24gfSBmcm9tIFwiLi9JY29uQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgVHlwb2dyYXBoeSB9IGZyb20gXCIuL1R5cG9ncmFwaHlcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js":
/*!***********************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Facebook: () => (/* reexport safe */ _Facebook__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Instagram: () => (/* reexport safe */ _Instagram__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   LinkedIn: () => (/* reexport safe */ _LinkedIn__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Twitter: () => (/* reexport safe */ _Twitter__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Facebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Facebook */ \"./node_modules/@mui/icons-material/esm/Facebook.js\");\n/* harmony import */ var _Instagram__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Instagram */ \"./node_modules/@mui/icons-material/esm/Instagram.js\");\n/* harmony import */ var _LinkedIn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./LinkedIn */ \"./node_modules/@mui/icons-material/esm/LinkedIn.js\");\n/* harmony import */ var _Twitter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Twitter */ \"./node_modules/@mui/icons-material/esm/Twitter.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1GYWNlYm9vayxJbnN0YWdyYW0sTGlua2VkSW4sVHdpdHRlciE9IS4vbm9kZV9tb2R1bGVzL0BtdWkvaWNvbnMtbWF0ZXJpYWwvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUNnRDtBQUNFO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0cHJvamVjdC8uL25vZGVfbW9kdWxlcy9AbXVpL2ljb25zLW1hdGVyaWFsL2VzbS9pbmRleC5qcz9lOWQ2Il0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBGYWNlYm9vayB9IGZyb20gXCIuL0ZhY2Vib29rXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgSW5zdGFncmFtIH0gZnJvbSBcIi4vSW5zdGFncmFtXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTGlua2VkSW4gfSBmcm9tIFwiLi9MaW5rZWRJblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFR3aXR0ZXIgfSBmcm9tIFwiLi9Ud2l0dGVyXCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\n");

/***/ }),

/***/ "./api/axios/axios.js":
/*!****************************!*\
  !*** ./api/axios/axios.js ***!
  \****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   adminUrl: () => (/* binding */ adminUrl),\n/* harmony export */   baseURL: () => (/* binding */ baseURL),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   product: () => (/* binding */ product),\n/* harmony export */   profile_pic: () => (/* binding */ profile_pic)\n/* harmony export */ });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-cookie */ \"react-cookie\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__]);\n([axios__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\nlet adminUrl = \"https://wtsacademy.dedicateddevelopers.us/api\";\nconst baseURL = adminUrl;\nlet axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__[\"default\"].create({\n    baseURL\n});\nconst cookie = new react_cookie__WEBPACK_IMPORTED_MODULE_1__.Cookies();\n\nconst product = (media)=>{\n    return `https://wtsacademy.dedicateddevelopers.us/uploads/product/${media}`;\n};\nconst profile_pic = (media)=>{\n    return `https://wtsacademy.dedicateddevelopers.us/uploads/user/profile_pic/${media}`;\n};\naxiosInstance.interceptors.request.use(async function(config) {\n    const token = cookie.get(\"token\");\n    if (token !== null || token !== undefined) {\n        config.headers[\"x-access-token\"] = token;\n    }\n    return Promise.resolve(config);\n}, function(err) {\n    return Promise.reject(err);\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosInstance);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9hcGkvYXhpb3MvYXhpb3MuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUEwQjtBQUNhO0FBQ3ZDLElBQUlFLFdBQVc7QUFFUixNQUFNQyxVQUFVRCxTQUFTO0FBQ2hDLElBQUlFLGdCQUFnQkosb0RBQVksQ0FBQztJQUMvQkc7QUFDRjtBQUVBLE1BQU1HLFNBQVMsSUFBSUwsaURBQU9BO0FBRU47QUFDYixNQUFNTSxVQUFVLENBQUNDO0lBQ3RCLE9BQU8sQ0FBQywwREFBMEQsRUFBRUEsTUFBTSxDQUFDO0FBQzdFLEVBQUU7QUFFSyxNQUFNQyxjQUFjLENBQUNEO0lBQzFCLE9BQU8sQ0FBQyxtRUFBbUUsRUFBRUEsTUFBTSxDQUFDO0FBQ3RGLEVBQUU7QUFDRkosY0FBY00sWUFBWSxDQUFDQyxPQUFPLENBQUNDLEdBQUcsQ0FDcEMsZUFBZ0JDLE1BQU07SUFDcEIsTUFBTUMsUUFBUVIsT0FBT1MsR0FBRyxDQUFDO0lBQ3pCLElBQUlELFVBQVUsUUFBUUEsVUFBVUUsV0FBVztRQUN6Q0gsT0FBT0ksT0FBTyxDQUFDLGlCQUFpQixHQUFHSDtJQUNyQztJQUNBLE9BQU9JLFFBQVFDLE9BQU8sQ0FBQ047QUFDekIsR0FDQSxTQUFVTyxHQUFHO0lBQ1gsT0FBT0YsUUFBUUcsTUFBTSxDQUFDRDtBQUN2QjtBQUdILGlFQUFlaEIsYUFBYUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHRwcm9qZWN0Ly4vYXBpL2F4aW9zL2F4aW9zLmpzP2I0YTMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBDb29raWVzIH0gZnJvbSBcInJlYWN0LWNvb2tpZVwiO1xyXG5sZXQgYWRtaW5VcmwgPSBcImh0dHBzOi8vd3RzYWNhZGVteS5kZWRpY2F0ZWRkZXZlbG9wZXJzLnVzL2FwaVwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGJhc2VVUkwgPSBhZG1pblVybDtcclxubGV0IGF4aW9zSW5zdGFuY2UgPSBheGlvcy5jcmVhdGUoe1xyXG4gIGJhc2VVUkwsXHJcbn0pO1xyXG5cclxuY29uc3QgY29va2llID0gbmV3IENvb2tpZXMoKTtcclxuXHJcbmV4cG9ydCB7IGFkbWluVXJsIH07XHJcbmV4cG9ydCBjb25zdCBwcm9kdWN0ID0gKG1lZGlhKSA9PiB7XHJcbiAgcmV0dXJuIGBodHRwczovL3d0c2FjYWRlbXkuZGVkaWNhdGVkZGV2ZWxvcGVycy51cy91cGxvYWRzL3Byb2R1Y3QvJHttZWRpYX1gO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHByb2ZpbGVfcGljID0gKG1lZGlhKSA9PiB7XHJcbiAgcmV0dXJuIGBodHRwczovL3d0c2FjYWRlbXkuZGVkaWNhdGVkZGV2ZWxvcGVycy51cy91cGxvYWRzL3VzZXIvcHJvZmlsZV9waWMvJHttZWRpYX1gO1xyXG59O1xyXG5heGlvc0luc3RhbmNlLmludGVyY2VwdG9ycy5yZXF1ZXN0LnVzZShcclxuICBhc3luYyBmdW5jdGlvbiAoY29uZmlnKSB7XHJcbiAgICBjb25zdCB0b2tlbiA9IGNvb2tpZS5nZXQoXCJ0b2tlblwiKTtcclxuICAgIGlmICh0b2tlbiAhPT0gbnVsbCB8fCB0b2tlbiAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIGNvbmZpZy5oZWFkZXJzW1wieC1hY2Nlc3MtdG9rZW5cIl0gPSB0b2tlbjtcclxuICAgIH1cclxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoY29uZmlnKTtcclxuICB9LFxyXG4gIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnIpO1xyXG4gICB9XHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBheGlvc0luc3RhbmNlOyJdLCJuYW1lcyI6WyJheGlvcyIsIkNvb2tpZXMiLCJhZG1pblVybCIsImJhc2VVUkwiLCJheGlvc0luc3RhbmNlIiwiY3JlYXRlIiwiY29va2llIiwicHJvZHVjdCIsIm1lZGlhIiwicHJvZmlsZV9waWMiLCJpbnRlcmNlcHRvcnMiLCJyZXF1ZXN0IiwidXNlIiwiY29uZmlnIiwidG9rZW4iLCJnZXQiLCJ1bmRlZmluZWQiLCJoZWFkZXJzIiwiUHJvbWlzZSIsInJlc29sdmUiLCJlcnIiLCJyZWplY3QiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./api/axios/axios.js\n");

/***/ }),

/***/ "./layout/footer/index.jsx":
/*!*********************************!*\
  !*** ./layout/footer/index.jsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!@mui/material */ \"__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!@mui/icons-material */ \"__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\");\n\n\n\n\n\nconst Footer = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"footer\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {\n            sx: {\n                bgcolor: \"slategrey\",\n                color: \"whitesmoke\",\n                p: 6\n            },\n            component: \"footer\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {\n                maxWidth: \"lg\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                    container: true,\n                    spacing: 4,\n                    justifyContent: \"space-between\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Site Links\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 14,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Home\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 17,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 20,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Add products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 23,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 13,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Quick Links\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 28,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Contact Us\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 31,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Privacy Policy\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 34,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Terms and Conditions\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 37,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 27,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Follow Us\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 42,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Facebook, {}, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 46,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 45,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Twitter, {}, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 49,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 48,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Instagram, {}, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 52,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 51,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.LinkedIn, {}, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 55,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 54,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 41,\n                            columnNumber: 21\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                    lineNumber: 12,\n                    columnNumber: 17\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n            lineNumber: 10,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\footer\\\\index.jsx\",\n        lineNumber: 8,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvZm9vdGVyL2luZGV4LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQTZCO0FBQ0g7QUFDbUQ7QUFDQTtBQUU3RSxNQUFNVyxTQUFTO0lBQ1gscUJBQ0ksOERBQUNDO2tCQUVHLDRFQUFDViw2R0FBR0E7WUFBQ1csSUFBSTtnQkFBRUMsU0FBUztnQkFBYUMsT0FBTTtnQkFBY0MsR0FBRztZQUFDO1lBQUdDLFdBQVU7c0JBQ3RFLDRFQUFDZCxtSEFBU0E7Z0JBQUNlLFVBQVM7MEJBQ2hCLDRFQUFDWiw4R0FBSUE7b0JBQUNhLFNBQVM7b0JBQUNDLFNBQVM7b0JBQUdDLGdCQUFlOztzQ0FDdkMsOERBQUNmLDhHQUFJQTs0QkFBQ2dCLElBQUk7NEJBQUNDLElBQUk7NEJBQUlDLElBQUk7NEJBQUdDLElBQUk7OzhDQUMxQiw4REFBQ3JCLG9IQUFVQTtvQ0FBQ3NCLFNBQVE7b0NBQUtYLE9BQU07b0NBQVFZLFlBQVk7OENBQUM7Ozs7Ozs4Q0FHcEQsOERBQUMzQixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFJRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7OENBRzdILDhEQUFDZixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFJRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7OENBRzdILDhEQUFDZixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFJRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7Ozs7Ozs7c0NBSWpJLDhEQUFDVCw4R0FBSUE7NEJBQUNnQixJQUFJOzRCQUFDQyxJQUFJOzRCQUFJQyxJQUFJOzRCQUFHQyxJQUFJOzs4Q0FDMUIsOERBQUNyQixvSEFBVUE7b0NBQUNzQixTQUFRO29DQUFLWCxPQUFNO29DQUFRWSxZQUFZOzhDQUFDOzs7Ozs7OENBR3BELDhEQUFDM0Isa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7OzhDQUc3SCw4REFBQ2Ysa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7OzhDQUc3SCw4REFBQ2Ysa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7Ozs7Ozs7O3NDQUlqSSw4REFBQ1QsOEdBQUlBOzRCQUFDZ0IsSUFBSTs0QkFBQ0MsSUFBSTs0QkFBSUMsSUFBSTs0QkFBR0MsSUFBSTs7OENBQzFCLDhEQUFDckIsb0hBQVVBO29DQUFDc0IsU0FBUTtvQ0FBS1gsT0FBTTtvQ0FBUVksWUFBWTs4Q0FBQzs7Ozs7OzhDQUdwRCw4REFBQ3RCLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDUixtSEFBUUE7Ozs7Ozs7Ozs7OENBRWIsOERBQUNGLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDUCxrSEFBT0E7Ozs7Ozs7Ozs7OENBRVosOERBQUNILG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDTixvSEFBU0E7Ozs7Ozs7Ozs7OENBRWQsOERBQUNKLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDTCxtSEFBUUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFTckM7QUFFQSxpRUFBZUMsTUFBTUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHRwcm9qZWN0Ly4vbGF5b3V0L2Zvb3Rlci9pbmRleC5qc3g/MmRlZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEJveCwgQ29udGFpbmVyLCBUeXBvZ3JhcGh5LCBJY29uQnV0dG9uLCBHcmlkIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCB7IEZhY2Vib29rLCBUd2l0dGVyLCBJbnN0YWdyYW0sIExpbmtlZEluIH0gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbCc7XHJcblxyXG5jb25zdCBGb290ZXIgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxmb290ZXI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8Qm94IHN4PXt7IGJnY29sb3I6ICdzbGF0ZWdyZXknLCBjb2xvcjpcIndoaXRlc21va2VcIiwgcDogNn19IGNvbXBvbmVudD1cImZvb3RlclwiPlxyXG4gICAgICAgICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwibGdcIj5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXs0fSBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezZ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgY29sb3I9XCJ3aGl0ZVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpdGUgTGlua3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSG9tZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dFNlY29uZGFyeVwiIHN0eWxlPXt7dGV4dERlY29yYXRpb246XCJub25lXCIsZGlzcGxheTpcImJsb2NrXCIsIGNvbG9yOlwid2hpdGVzbW9rZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9kdWN0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dFNlY29uZGFyeVwiIHN0eWxlPXt7dGV4dERlY29yYXRpb246XCJub25lXCIsZGlzcGxheTpcImJsb2NrXCIsIGNvbG9yOlwid2hpdGVzbW9rZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGQgcHJvZHVjdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezZ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgY29sb3I9XCJ3aGl0ZVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFF1aWNrIExpbmtzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB2YXJpYW50PVwic3VidGl0bGUxXCIgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgc3R5bGU9e3t0ZXh0RGVjb3JhdGlvbjpcIm5vbmVcIixkaXNwbGF5OlwiYmxvY2tcIiwgY29sb3I6XCJ3aGl0ZXNtb2tlXCJ9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgVXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpdmFjeSBQb2xpY3lcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVybXMgYW5kIENvbmRpdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezZ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgY29sb3I9XCJ3aGl0ZVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvbGxvdyBVc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGhyZWY9XCIjXCIgY29sb3I9XCJpbmhlcml0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFjZWJvb2sgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiI1wiIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR3aXR0ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiI1wiIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluc3RhZ3JhbSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGhyZWY9XCIjXCIgY29sb3I9XCJpbmhlcml0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua2VkSW4gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvZm9vdGVyPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZvb3RlcjsiXSwibmFtZXMiOlsiTGluayIsIlJlYWN0IiwiQm94IiwiQ29udGFpbmVyIiwiVHlwb2dyYXBoeSIsIkljb25CdXR0b24iLCJHcmlkIiwiRmFjZWJvb2siLCJUd2l0dGVyIiwiSW5zdGFncmFtIiwiTGlua2VkSW4iLCJGb290ZXIiLCJmb290ZXIiLCJzeCIsImJnY29sb3IiLCJjb2xvciIsInAiLCJjb21wb25lbnQiLCJtYXhXaWR0aCIsImNvbnRhaW5lciIsInNwYWNpbmciLCJqdXN0aWZ5Q29udGVudCIsIml0ZW0iLCJ4cyIsInNtIiwibWQiLCJ2YXJpYW50IiwiZ3V0dGVyQm90dG9tIiwiaHJlZiIsInN0eWxlIiwidGV4dERlY29yYXRpb24iLCJkaXNwbGF5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./layout/footer/index.jsx\n");

/***/ }),

/***/ "./layout/header/index.jsx":
/*!*********************************!*\
  !*** ./layout/header/index.jsx ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Header)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material/AppBar */ \"@mui/material/AppBar\");\n/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material/Box */ \"@mui/material/Box\");\n/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material/Toolbar */ \"@mui/material/Toolbar\");\n/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/Typography */ \"@mui/material/Typography\");\n/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/Button */ \"@mui/material/Button\");\n/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/IconButton */ \"@mui/material/IconButton\");\n/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/Menu */ \"@mui/icons-material/Menu\");\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material/Container */ \"@mui/material/Container\");\n/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_9__);\n/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material/MenuItem */ \"@mui/material/MenuItem\");\n/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10__);\n/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/material/Menu */ \"@mui/material/Menu\");\n/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11__);\n/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/material/Tooltip */ \"@mui/material/Tooltip\");\n/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__);\n/* harmony import */ var _api_axios_axios__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/api/axios/axios */ \"./api/axios/axios.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_14__);\n/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-cookie */ \"react-cookie\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_axios_axios__WEBPACK_IMPORTED_MODULE_13__, react_cookie__WEBPACK_IMPORTED_MODULE_15__]);\n([_api_axios_axios__WEBPACK_IMPORTED_MODULE_13__, react_cookie__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n\n\n\n\n\n// import img1 from '../../../Images/download1.jpg';\n// import img2 from '../../../Images/download 2.jpg'\n\n\n\nconst pages = [\n    \"Home\",\n    \"Productlist\",\n    \"CreateData\",\n    \"ProfileDetail\"\n];\nconst settings = [\n    \"Login\",\n    \"Register\"\n];\nfunction Header() {\n    const cookie = new react_cookie__WEBPACK_IMPORTED_MODULE_15__.Cookies();\n    const token = cookie.get(\"token\");\n    const image = cookie.get(\"profile_pic\");\n    const [anchorElNav, setAnchorElNav] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [anchorElUser, setAnchorElUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const handleOpenNavMenu = (event)=>{\n        setAnchorElNav(event.currentTarget);\n    };\n    const handleOpenUserMenu = (event)=>{\n        setAnchorElUser(event.currentTarget);\n    };\n    const handleCloseNavMenu = ()=>{\n        setAnchorElNav(null);\n    };\n    const handleCloseUserMenu = ()=>{\n        setAnchorElUser(null);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default()), {\n        position: \"static\",\n        sx: {\n            backgroundColor: \"orangered\"\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Container__WEBPACK_IMPORTED_MODULE_9___default()), {\n            maxWidth: \"xl\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                lg: \"flex\",\n                                md: \"flex\",\n                                xs: \"none\"\n                            }\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                            variant: \"h4\",\n                            noWrap: true,\n                            style: {\n                                mr: 2,\n                                display: {\n                                    xs: \"none\",\n                                    md: \"flex\"\n                                },\n                                fontFamily: \"monospace\",\n                                fontWeight: 300,\n                                letterSpacing: \".3rem\",\n                                color: \"inherit\",\n                                textDecoration: \"none\"\n                            },\n                            children: \"UniTech\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                            lineNumber: 58,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 54,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            }\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {\n                                size: \"large\",\n                                \"aria-label\": \"account of current user\",\n                                \"aria-controls\": \"menu-appbar\",\n                                \"aria-haspopup\": \"true\",\n                                onClick: handleOpenNavMenu,\n                                color: \"inherit\",\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8___default()), {}, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                    lineNumber: 86,\n                                    columnNumber: 15\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 78,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default()), {\n                                id: \"menu-appbar\",\n                                anchorEl: anchorElNav,\n                                anchorOrigin: {\n                                    vertical: \"bottom\",\n                                    horizontal: \"left\"\n                                },\n                                keepMounted: true,\n                                transformOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"left\"\n                                },\n                                open: Boolean(anchorElNav),\n                                onClose: handleCloseNavMenu,\n                                sx: {\n                                    display: {\n                                        xs: \"block\",\n                                        md: \"none\"\n                                    }\n                                },\n                                children: pages.map((page)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                        onClick: handleCloseNavMenu,\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                            textAlign: \"center\",\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {\n                                                href: `/cms/${page.toLowerCase()}`,\n                                                style: {\n                                                    textDecoration: \"none\",\n                                                    color: \"inherit\"\n                                                },\n                                                children: page\n                                            }, void 0, false, {\n                                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                                lineNumber: 110,\n                                                columnNumber: 21\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                            lineNumber: 109,\n                                            columnNumber: 19\n                                        }, this)\n                                    }, page, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 107,\n                                        columnNumber: 17\n                                    }, this))\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 88,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 77,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                lg: \"none\",\n                                md: \"none\",\n                                xs: \"block\"\n                            }\n                        }\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 121,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                        variant: \"h5\",\n                        sx: {\n                            mr: 2,\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            },\n                            flexGrow: 1,\n                            fontFamily: \"monospace\",\n                            fontWeight: 700,\n                            letterSpacing: \".3rem\",\n                            color: \"inherit\",\n                            textDecoration: \"none\"\n                        },\n                        children: \"UniTech\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 124,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"none\",\n                                md: \"flex\"\n                            }\n                        },\n                        children: pages.map((page)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default()), {\n                                onClick: handleCloseNavMenu,\n                                sx: {\n                                    my: 2,\n                                    color: \"white\",\n                                    display: \"block\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {\n                                    href: `/cms/${page.toLowerCase()}`,\n                                    style: {\n                                        textDecoration: \"none\",\n                                        color: \"white\"\n                                    },\n                                    children: page\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                    lineNumber: 148,\n                                    columnNumber: 17\n                                }, this)\n                            }, page, false, {\n                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 143,\n                                columnNumber: 15\n                            }, this))\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 141,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 0\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default()), {\n                                title: \"Open settings\",\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {\n                                    onClick: handleOpenUserMenu,\n                                    sx: {\n                                        p: 0\n                                    },\n                                    children: token !== null && token !== undefined ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                                        style: {\n                                            width: \"30px\",\n                                            height: \"30px\",\n                                            borderRadius: \"100%\"\n                                        },\n                                        src: (0,_api_axios_axios__WEBPACK_IMPORTED_MODULE_13__.profile_pic)(image)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 160,\n                                        columnNumber: 59\n                                    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                                        style: {\n                                            width: \"30px\",\n                                            height: \"30px\",\n                                            borderRadius: \"100%\"\n                                        },\n                                        src: \"\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 160,\n                                        columnNumber: 154\n                                    }, this)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                    lineNumber: 159,\n                                    columnNumber: 15\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 158,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default()), {\n                                sx: {\n                                    mt: \"45px\"\n                                },\n                                id: \"menu-appbar\",\n                                anchorEl: anchorElUser,\n                                anchorOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"right\"\n                                },\n                                keepMounted: true,\n                                transformOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"right\"\n                                },\n                                open: Boolean(anchorElUser),\n                                onClose: handleCloseUserMenu,\n                                children: settings?.map((setting)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                        onClick: handleCloseUserMenu,\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                            textAlign: \"center\",\n                                            children: [\n                                                \" \",\n                                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {\n                                                    href: `/auth/${setting.toLowerCase()}`,\n                                                    style: {\n                                                        textDecoration: \"none\",\n                                                        color: \"inherit\"\n                                                    },\n                                                    children: setting\n                                                }, void 0, false, {\n                                                    fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                                    lineNumber: 181,\n                                                    columnNumber: 51\n                                                }, this)\n                                            ]\n                                        }, void 0, true, {\n                                            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                            lineNumber: 181,\n                                            columnNumber: 19\n                                        }, this)\n                                    }, setting, false, {\n                                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 180,\n                                        columnNumber: 17\n                                    }, this))\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 163,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 157,\n                        columnNumber: 11\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n                lineNumber: 53,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n            lineNumber: 52,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\header\\\\index.jsx\",\n        lineNumber: 51,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvaGVhZGVyL2luZGV4LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUF3QztBQUNFO0FBQ047QUFDUTtBQUNNO0FBQ1I7QUFDUTtBQUNGO0FBQ0E7QUFDRjtBQUNSO0FBQ007QUFDNUMsb0RBQW9EO0FBQ3BELG9EQUFvRDtBQUNKO0FBQ25CO0FBQ1U7QUFFdkMsTUFBTWdCLFFBQVE7SUFBQztJQUFPO0lBQWU7SUFBYztDQUFnQjtBQUNuRSxNQUFNQyxXQUFXO0lBQUM7SUFBUTtDQUFXO0FBRXRCLFNBQVNDO0lBQ3RCLE1BQU1DLFNBQVMsSUFBSUosa0RBQU9BO0lBRTFCLE1BQU1LLFFBQVFELE9BQU9FLEdBQUcsQ0FBQztJQUN6QixNQUFNQyxRQUFRSCxPQUFPRSxHQUFHLENBQUM7SUFFekIsTUFBTSxDQUFDRSxhQUFhQyxlQUFlLEdBQUd2QiwrQ0FBUUEsQ0FBQztJQUMvQyxNQUFNLENBQUN3QixjQUFjQyxnQkFBZ0IsR0FBR3pCLCtDQUFRQSxDQUFDO0lBSWpELE1BQU0wQixvQkFBb0IsQ0FBQ0M7UUFDekJKLGVBQWVJLE1BQU1DLGFBQWE7SUFDcEM7SUFFQSxNQUFNQyxxQkFBcUIsQ0FBQ0Y7UUFDMUJGLGdCQUFnQkUsTUFBTUMsYUFBYTtJQUNyQztJQUVBLE1BQU1FLHFCQUFxQjtRQUN6QlAsZUFBZTtJQUNqQjtJQUVBLE1BQU1RLHNCQUFzQjtRQUMxQk4sZ0JBQWdCO0lBQ2xCO0lBR0EscUJBQ0UsOERBQUN4Qiw2REFBTUE7UUFBQytCLFVBQVM7UUFBU0MsSUFBSTtZQUFFQyxpQkFBaUI7UUFBWTtrQkFDM0QsNEVBQUMxQixnRUFBU0E7WUFBQzJCLFVBQVM7c0JBQ2xCLDRFQUFDaEMsOERBQU9BOztrQ0FDUiw4REFBQ0QsMERBQUdBO3dCQUFDK0IsSUFBSTs0QkFBRUcsVUFBVTs0QkFBR0MsU0FBUztnQ0FBRUMsSUFBSTtnQ0FBUUMsSUFBSTtnQ0FBUUMsSUFBRzs0QkFBTzt3QkFBRTtrQ0FJckUsNEVBQUNwQyxpRUFBVUE7NEJBQ1RxQyxTQUFROzRCQUNSQyxNQUFNOzRCQUNOQyxPQUFPO2dDQUNMQyxJQUFJO2dDQUNKUCxTQUFTO29DQUFFRyxJQUFJO29DQUFRRCxJQUFJO2dDQUFPO2dDQUNsQ00sWUFBWTtnQ0FDWkMsWUFBWTtnQ0FDWkMsZUFBZTtnQ0FDZkMsT0FBTztnQ0FDUEMsZ0JBQWdCOzRCQUVsQjtzQ0FDRDs7Ozs7Ozs7Ozs7a0NBTUQsOERBQUMvQywwREFBR0E7d0JBQUMrQixJQUFJOzRCQUFFRyxVQUFVOzRCQUFHQyxTQUFTO2dDQUFFRyxJQUFJO2dDQUFRRCxJQUFJOzRCQUFPO3dCQUFFOzswQ0FDMUQsOERBQUNqQyxpRUFBVUE7Z0NBQ1Q0QyxNQUFLO2dDQUNMQyxjQUFXO2dDQUNYQyxpQkFBYztnQ0FDZEMsaUJBQWM7Z0NBQ2RDLFNBQVM1QjtnQ0FDVHNCLE9BQU07MENBRU4sNEVBQUN6QyxpRUFBUUE7Ozs7Ozs7Ozs7MENBRVgsOERBQUNHLDREQUFJQTtnQ0FDSDZDLElBQUc7Z0NBQ0hDLFVBQVVsQztnQ0FDVm1DLGNBQWM7b0NBQ1pDLFVBQVU7b0NBQ1ZDLFlBQVk7Z0NBQ2Q7Z0NBQ0FDLFdBQVc7Z0NBQ1hDLGlCQUFpQjtvQ0FDZkgsVUFBVTtvQ0FDVkMsWUFBWTtnQ0FDZDtnQ0FDQUcsTUFBTUMsUUFBUXpDO2dDQUNkMEMsU0FBU2xDO2dDQUNURyxJQUFJO29DQUNGSSxTQUFTO3dDQUFFRyxJQUFJO3dDQUFTRCxJQUFJO29DQUFPO2dDQUNyQzswQ0FFQ3hCLE1BQU1rRCxHQUFHLENBQUMsQ0FBQ0MscUJBQ1YsOERBQUN6RCxnRUFBUUE7d0NBQVk2QyxTQUFTeEI7a0RBRTVCLDRFQUFDMUIsaUVBQVVBOzRDQUFDK0QsV0FBVTtzREFDcEIsNEVBQUN0RCxtREFBSUE7Z0RBQUN1RCxNQUFNLENBQUMsS0FBSyxFQUFFRixLQUFLRyxXQUFXLEdBQUcsQ0FBQztnREFBRTFCLE9BQU87b0RBQUVNLGdCQUFnQjtvREFBUUQsT0FBTztnREFBVTswREFDekZrQjs7Ozs7Ozs7Ozs7dUNBSlFBOzs7Ozs7Ozs7Ozs7Ozs7O2tDQWNyQiw4REFBQ2hFLDBEQUFHQTt3QkFBQytCLElBQUk7NEJBQUVHLFVBQVU7NEJBQUdDLFNBQVM7Z0NBQUVDLElBQUk7Z0NBQVFDLElBQUk7Z0NBQVFDLElBQUc7NEJBQVE7d0JBQUU7Ozs7OztrQ0FHeEUsOERBQUNwQyxpRUFBVUE7d0JBQ1RxQyxTQUFRO3dCQUVSUixJQUFJOzRCQUNGVyxJQUFJOzRCQUNKUCxTQUFTO2dDQUFFRyxJQUFJO2dDQUFRRCxJQUFJOzRCQUFPOzRCQUNsQ0gsVUFBVTs0QkFDVlMsWUFBWTs0QkFDWkMsWUFBWTs0QkFDWkMsZUFBZTs0QkFDZkMsT0FBTzs0QkFDUEMsZ0JBQWdCO3dCQUNsQjtrQ0FDRDs7Ozs7O2tDQUlELDhEQUFDL0MsMERBQUdBO3dCQUFDK0IsSUFBSTs0QkFBRUcsVUFBVTs0QkFBR0MsU0FBUztnQ0FBRUcsSUFBSTtnQ0FBUUQsSUFBSTs0QkFBTzt3QkFBRTtrQ0FDekR4QixNQUFNa0QsR0FBRyxDQUFDLENBQUNDLHFCQUNWLDhEQUFDN0QsNkRBQU1BO2dDQUVMaUQsU0FBU3hCO2dDQUNURyxJQUFJO29DQUFFcUMsSUFBSTtvQ0FBR3RCLE9BQU87b0NBQVNYLFNBQVM7Z0NBQVE7MENBRTlDLDRFQUFDeEIsbURBQUlBO29DQUFDdUQsTUFBTSxDQUFDLEtBQUssRUFBRUYsS0FBS0csV0FBVyxHQUFHLENBQUM7b0NBQUUxQixPQUFPO3dDQUFFTSxnQkFBZ0I7d0NBQVFELE9BQU87b0NBQVE7OENBQ3ZGa0I7Ozs7OzsrQkFMRUE7Ozs7Ozs7Ozs7a0NBYVgsOERBQUNoRSwwREFBR0E7d0JBQUMrQixJQUFJOzRCQUFFRyxVQUFVO3dCQUFFOzswQ0FDckIsOERBQUN6QiwrREFBT0E7Z0NBQUM0RCxPQUFNOzBDQUNiLDRFQUFDakUsaUVBQVVBO29DQUFDZ0QsU0FBU3pCO29DQUFvQkksSUFBSTt3Q0FBRXVDLEdBQUc7b0NBQUU7OENBQ2pEckQsVUFBVSxRQUFRQSxVQUFVc0QsMEJBQWEsOERBQUNDO3dDQUFJL0IsT0FBTzs0Q0FBQ2dDLE9BQU07NENBQVFDLFFBQU87NENBQVFDLGNBQWE7d0NBQU07d0NBQUdDLEtBQUtsRSw4REFBV0EsQ0FBQ1M7Ozs7OzZEQUFjLDhEQUFDcUQ7d0NBQUkvQixPQUFPOzRDQUFDZ0MsT0FBTTs0Q0FBUUMsUUFBTzs0Q0FBUUMsY0FBYTt3Q0FBTTt3Q0FBR0MsS0FBSzs7Ozs7Ozs7Ozs7Ozs7OzswQ0FHbE4sOERBQUNwRSw0REFBSUE7Z0NBQ0h1QixJQUFJO29DQUFFOEMsSUFBSTtnQ0FBTztnQ0FDakJ4QixJQUFHO2dDQUNIQyxVQUFVaEM7Z0NBQ1ZpQyxjQUFjO29DQUNaQyxVQUFVO29DQUNWQyxZQUFZO2dDQUNkO2dDQUNBQyxXQUFXO2dDQUNYQyxpQkFBaUI7b0NBQ2ZILFVBQVU7b0NBQ1ZDLFlBQVk7Z0NBQ2Q7Z0NBQ0FHLE1BQU1DLFFBQVF2QztnQ0FDZHdDLFNBQVNqQzswQ0FFTGYsVUFBVWlELElBQUksQ0FBQ2Usd0JBQ2pCLDhEQUFDdkUsZ0VBQVFBO3dDQUFlNkMsU0FBU3ZCO2tEQUMvQiw0RUFBQzNCLGlFQUFVQTs0Q0FBQytELFdBQVU7O2dEQUFTOzhEQUFDLDhEQUFDdEQsbURBQUlBO29EQUFDdUQsTUFBTSxDQUFDLE1BQU0sRUFBRVksUUFBUVgsV0FBVyxHQUFHLENBQUM7b0RBQUUxQixPQUFPO3dEQUFFTSxnQkFBZ0I7d0RBQVFELE9BQU87b0RBQVU7OERBQzNIZ0M7Ozs7Ozs7Ozs7Ozt1Q0FGUUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZS9CIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dHByb2plY3QvLi9sYXlvdXQvaGVhZGVyL2luZGV4LmpzeD80YTY5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbXVpL21hdGVyaWFsL0FwcEJhcic7XHJcbmltcG9ydCBCb3ggZnJvbSAnQG11aS9tYXRlcmlhbC9Cb3gnO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbXVpL21hdGVyaWFsL1Rvb2xiYXInO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbXVpL21hdGVyaWFsL1R5cG9ncmFwaHknO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtdWkvbWF0ZXJpYWwvQnV0dG9uJztcclxuaW1wb3J0IEljb25CdXR0b24gZnJvbSAnQG11aS9tYXRlcmlhbC9JY29uQnV0dG9uJztcclxuaW1wb3J0IE1lbnVJY29uIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvTWVudSc7XHJcbmltcG9ydCBDb250YWluZXIgZnJvbSAnQG11aS9tYXRlcmlhbC9Db250YWluZXInO1xyXG5pbXBvcnQgTWVudUl0ZW0gZnJvbSAnQG11aS9tYXRlcmlhbC9NZW51SXRlbSc7XHJcbmltcG9ydCBNZW51IGZyb20gJ0BtdWkvbWF0ZXJpYWwvTWVudSc7XHJcbmltcG9ydCBUb29sdGlwIGZyb20gJ0BtdWkvbWF0ZXJpYWwvVG9vbHRpcCc7XHJcbi8vIGltcG9ydCBpbWcxIGZyb20gJy4uLy4uLy4uL0ltYWdlcy9kb3dubG9hZDEuanBnJztcclxuLy8gaW1wb3J0IGltZzIgZnJvbSAnLi4vLi4vLi4vSW1hZ2VzL2Rvd25sb2FkIDIuanBnJ1xyXG5pbXBvcnQgeyBwcm9maWxlX3BpYyB9IGZyb20gJ0AvYXBpL2F4aW9zL2F4aW9zJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IHsgQ29va2llcyB9IGZyb20gJ3JlYWN0LWNvb2tpZSc7XHJcblxyXG5jb25zdCBwYWdlcyA9IFsnSG9tZScsJ1Byb2R1Y3RsaXN0JywgJ0NyZWF0ZURhdGEnLCAnUHJvZmlsZURldGFpbCddO1xyXG5jb25zdCBzZXR0aW5ncyA9IFsnTG9naW4nLCdSZWdpc3RlciddO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVhZGVyKCkge1xyXG4gIGNvbnN0IGNvb2tpZSA9IG5ldyBDb29raWVzKCk7XHJcbiAgXHJcbiAgY29uc3QgdG9rZW4gPSBjb29raWUuZ2V0KFwidG9rZW5cIik7XHJcbiAgY29uc3QgaW1hZ2UgPSBjb29raWUuZ2V0KFwicHJvZmlsZV9waWNcIik7XHJcblxyXG4gIGNvbnN0IFthbmNob3JFbE5hdiwgc2V0QW5jaG9yRWxOYXZdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FuY2hvckVsVXNlciwgc2V0QW5jaG9yRWxVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBcclxuXHJcbiAgY29uc3QgaGFuZGxlT3Blbk5hdk1lbnUgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldEFuY2hvckVsTmF2KGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5Vc2VyTWVudSA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0QW5jaG9yRWxVc2VyKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsb3NlTmF2TWVudSA9ICgpID0+IHtcclxuICAgIHNldEFuY2hvckVsTmF2KG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsb3NlVXNlck1lbnUgPSAoKSA9PiB7XHJcbiAgICBzZXRBbmNob3JFbFVzZXIobnVsbCk7XHJcbiAgfVxyXG4gIFxyXG4gXHJcbiAgcmV0dXJuIChcclxuICAgIDxBcHBCYXIgcG9zaXRpb249XCJzdGF0aWNcIiBzeD17eyBiYWNrZ3JvdW5kQ29sb3I6ICdvcmFuZ2VyZWQnIH19PlxyXG4gICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwieGxcIj5cclxuICAgICAgICA8VG9vbGJhcj5cclxuICAgICAgICA8Qm94IHN4PXt7IGZsZXhHcm93OiAxLCBkaXNwbGF5OiB7IGxnOiAnZmxleCcsIG1kOiAnZmxleCcsIHhzOidub25lJyB9IH19PlxyXG4gICAgXHJcbiAgICAgICAgey8qIDxpbWcgc3R5bGU9e3t3aWR0aDpcIjEwMHB4XCIsIGhlaWdodDpcIjgwcHhcIixkaXNwbGF5Ont4czonbm9uZScsIG1kOidmbGV4J319fSBzcmM9e2ltZzF9IGFsdD1cIlwiIC8+ICAqL31cclxuICAgICAgICBcclxuICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJoNFwiXHJcbiAgICAgICAgICAgIG5vV3JhcFxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIG1yOiAyLFxyXG4gICAgICAgICAgICAgIGRpc3BsYXk6IHsgeHM6ICdub25lJywgbWQ6ICdmbGV4JyB9LFxyXG4gICAgICAgICAgICAgIGZvbnRGYW1pbHk6ICdtb25vc3BhY2UnLFxyXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDMwMCxcclxuICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiAnLjNyZW0nLFxyXG4gICAgICAgICAgICAgIGNvbG9yOiAnaW5oZXJpdCcsXHJcbiAgICAgICAgICAgICAgdGV4dERlY29yYXRpb246ICdub25lJyxcclxuICAgICAgICAgICAgICAvLyBtYXJnaW5Ub3A6XCIzMHB4XCJcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgIFVuaVRlY2hcclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZmxleEdyb3c6IDEsIGRpc3BsYXk6IHsgeHM6ICdmbGV4JywgbWQ6ICdub25lJyB9IH19PlxyXG4gICAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImFjY291bnQgb2YgY3VycmVudCB1c2VyXCJcclxuICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwibWVudS1hcHBiYXJcIlxyXG4gICAgICAgICAgICAgIGFyaWEtaGFzcG9wdXA9XCJ0cnVlXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuTmF2TWVudX1cclxuICAgICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPE1lbnVJY29uIC8+XHJcbiAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgPE1lbnVcclxuICAgICAgICAgICAgICBpZD1cIm1lbnUtYXBwYmFyXCJcclxuICAgICAgICAgICAgICBhbmNob3JFbD17YW5jaG9yRWxOYXZ9XHJcbiAgICAgICAgICAgICAgYW5jaG9yT3JpZ2luPXt7XHJcbiAgICAgICAgICAgICAgICB2ZXJ0aWNhbDogJ2JvdHRvbScsXHJcbiAgICAgICAgICAgICAgICBob3Jpem9udGFsOiAnbGVmdCcsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBrZWVwTW91bnRlZFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbj17e1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWw6ICd0b3AnLFxyXG4gICAgICAgICAgICAgICAgaG9yaXpvbnRhbDogJ2xlZnQnLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgb3Blbj17Qm9vbGVhbihhbmNob3JFbE5hdil9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VOYXZNZW51fVxyXG4gICAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiB7IHhzOiAnYmxvY2snLCBtZDogJ25vbmUnIH0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtwYWdlcy5tYXAoKHBhZ2UpID0+IChcclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSBrZXk9e3BhZ2V9IG9uQ2xpY2s9e2hhbmRsZUNsb3NlTmF2TWVudX0+XHJcbiAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvY21zLyR7cGFnZS50b0xvd2VyQ2FzZSgpfWB9IHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGNvbG9yOiAnaW5oZXJpdCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGFnZX1cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L01lbnU+XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZmxleEdyb3c6IDEsIGRpc3BsYXk6IHsgbGc6ICdub25lJywgbWQ6ICdub25lJywgeHM6J2Jsb2NrJyB9IH19PlxyXG4gICAgICAgICAgey8qIDxpbWcgc3R5bGU9e3t3aWR0aDpcIjEzMHB4XCIsIGhlaWdodDpcIjEwMHB4XCJ9fSBzcmM9e2ltZzF9IGFsdD1cIlwiIC8+ICovfVxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICB2YXJpYW50PVwiaDVcIlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICBtcjogMixcclxuICAgICAgICAgICAgICBkaXNwbGF5OiB7IHhzOiAnZmxleCcsIG1kOiAnbm9uZScgfSxcclxuICAgICAgICAgICAgICBmbGV4R3JvdzogMSxcclxuICAgICAgICAgICAgICBmb250RmFtaWx5OiAnbW9ub3NwYWNlJyxcclxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXHJcbiAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogJy4zcmVtJyxcclxuICAgICAgICAgICAgICBjb2xvcjogJ2luaGVyaXQnLFxyXG4gICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFVuaVRlY2hcclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuXHJcbiAgICAgICAgICA8Qm94IHN4PXt7IGZsZXhHcm93OiAxLCBkaXNwbGF5OiB7IHhzOiAnbm9uZScsIG1kOiAnZmxleCcgfSB9fT5cclxuICAgICAgICAgICAge3BhZ2VzLm1hcCgocGFnZSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIGtleT17cGFnZX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlTmF2TWVudX1cclxuICAgICAgICAgICAgICAgIHN4PXt7IG15OiAyLCBjb2xvcjogJ3doaXRlJywgZGlzcGxheTogJ2Jsb2NrJyB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvY21zLyR7cGFnZS50b0xvd2VyQ2FzZSgpfWB9IHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGNvbG9yOiAnd2hpdGUnIH19PlxyXG4gICAgICAgICAgICAgICAgICB7cGFnZX1cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZmxleEdyb3c6IDAgfX0+XHJcbiAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiT3BlbiBzZXR0aW5nc1wiPlxyXG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uIG9uQ2xpY2s9e2hhbmRsZU9wZW5Vc2VyTWVudX0gc3g9e3sgcDogMCB9fT5cclxuICAgICAgICAgICAgICAgIHt0b2tlbiAhPT0gbnVsbCAmJiB0b2tlbiAhPT0gdW5kZWZpbmVkID8gKDxpbWcgc3R5bGU9e3t3aWR0aDpcIjMwcHhcIiwgaGVpZ2h0OlwiMzBweFwiLCBib3JkZXJSYWRpdXM6XCIxMDAlXCJ9fSBzcmM9e3Byb2ZpbGVfcGljKGltYWdlKX0vPikgOiAoPGltZyBzdHlsZT17e3dpZHRoOlwiMzBweFwiLCBoZWlnaHQ6XCIzMHB4XCIsIGJvcmRlclJhZGl1czpcIjEwMCVcIn19IHNyYz0gXCJcIi8+KX1cclxuICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgPE1lbnVcclxuICAgICAgICAgICAgICBzeD17eyBtdDogJzQ1cHgnIH19XHJcbiAgICAgICAgICAgICAgaWQ9XCJtZW51LWFwcGJhclwiXHJcbiAgICAgICAgICAgICAgYW5jaG9yRWw9e2FuY2hvckVsVXNlcn1cclxuICAgICAgICAgICAgICBhbmNob3JPcmlnaW49e3tcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsOiAndG9wJyxcclxuICAgICAgICAgICAgICAgIGhvcml6b250YWw6ICdyaWdodCcsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBrZWVwTW91bnRlZFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbj17e1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWw6ICd0b3AnLFxyXG4gICAgICAgICAgICAgICAgaG9yaXpvbnRhbDogJ3JpZ2h0JyxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIG9wZW49e0Jvb2xlYW4oYW5jaG9yRWxVc2VyKX1cclxuICAgICAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZVVzZXJNZW51fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAge3NldHRpbmdzPy5tYXAoKHNldHRpbmcpID0+IChcclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSBrZXk9e3NldHRpbmd9IG9uQ2xpY2s9e2hhbmRsZUNsb3NlVXNlck1lbnV9PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB0ZXh0QWxpZ249XCJjZW50ZXJcIj4gPExpbmsgaHJlZj17YC9hdXRoLyR7c2V0dGluZy50b0xvd2VyQ2FzZSgpfWB9IHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGNvbG9yOiAnaW5oZXJpdCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2V0dGluZ31cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9Ub29sYmFyPlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvQXBwQmFyPlxyXG4gICk7XHJcbn1cclxuXHJcblxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIkFwcEJhciIsIkJveCIsIlRvb2xiYXIiLCJUeXBvZ3JhcGh5IiwiQnV0dG9uIiwiSWNvbkJ1dHRvbiIsIk1lbnVJY29uIiwiQ29udGFpbmVyIiwiTWVudUl0ZW0iLCJNZW51IiwiVG9vbHRpcCIsInByb2ZpbGVfcGljIiwiTGluayIsIkNvb2tpZXMiLCJwYWdlcyIsInNldHRpbmdzIiwiSGVhZGVyIiwiY29va2llIiwidG9rZW4iLCJnZXQiLCJpbWFnZSIsImFuY2hvckVsTmF2Iiwic2V0QW5jaG9yRWxOYXYiLCJhbmNob3JFbFVzZXIiLCJzZXRBbmNob3JFbFVzZXIiLCJoYW5kbGVPcGVuTmF2TWVudSIsImV2ZW50IiwiY3VycmVudFRhcmdldCIsImhhbmRsZU9wZW5Vc2VyTWVudSIsImhhbmRsZUNsb3NlTmF2TWVudSIsImhhbmRsZUNsb3NlVXNlck1lbnUiLCJwb3NpdGlvbiIsInN4IiwiYmFja2dyb3VuZENvbG9yIiwibWF4V2lkdGgiLCJmbGV4R3JvdyIsImRpc3BsYXkiLCJsZyIsIm1kIiwieHMiLCJ2YXJpYW50Iiwibm9XcmFwIiwic3R5bGUiLCJtciIsImZvbnRGYW1pbHkiLCJmb250V2VpZ2h0IiwibGV0dGVyU3BhY2luZyIsImNvbG9yIiwidGV4dERlY29yYXRpb24iLCJzaXplIiwiYXJpYS1sYWJlbCIsImFyaWEtY29udHJvbHMiLCJhcmlhLWhhc3BvcHVwIiwib25DbGljayIsImlkIiwiYW5jaG9yRWwiLCJhbmNob3JPcmlnaW4iLCJ2ZXJ0aWNhbCIsImhvcml6b250YWwiLCJrZWVwTW91bnRlZCIsInRyYW5zZm9ybU9yaWdpbiIsIm9wZW4iLCJCb29sZWFuIiwib25DbG9zZSIsIm1hcCIsInBhZ2UiLCJ0ZXh0QWxpZ24iLCJocmVmIiwidG9Mb3dlckNhc2UiLCJteSIsInRpdGxlIiwicCIsInVuZGVmaW5lZCIsImltZyIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwic3JjIiwibXQiLCJzZXR0aW5nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./layout/header/index.jsx\n");

/***/ }),

/***/ "./layout/wrapper/Wrapper.jsx":
/*!************************************!*\
  !*** ./layout/wrapper/Wrapper.jsx ***!
  \************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../header */ \"./layout/header/index.jsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../footer */ \"./layout/footer/index.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_2__]);\n_header__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst Wrapper = ({ children })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"flex flex-col min-h-screen\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\wrapper\\\\Wrapper.jsx\",\n                lineNumber: 8,\n                columnNumber: 14\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: \"flex-grow\",\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\wrapper\\\\Wrapper.jsx\",\n                lineNumber: 9,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\wrapper\\\\Wrapper.jsx\",\n                lineNumber: 10,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Project3\\\\nextproject\\\\layout\\\\wrapper\\\\Wrapper.jsx\",\n        lineNumber: 7,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvd3JhcHBlci9XcmFwcGVyLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUEwQjtBQUNLO0FBQ0E7QUFFL0IsTUFBTUcsVUFBVSxDQUFDLEVBQUVDLFFBQVEsRUFBRTtJQUN6QixxQkFDSSw4REFBQ0M7UUFBSUMsV0FBVTs7MEJBQ1YsOERBQUNMLCtDQUFNQTs7Ozs7MEJBQ1IsOERBQUNNO2dCQUFLRCxXQUFVOzBCQUFhRjs7Ozs7OzBCQUM3Qiw4REFBQ0YsK0NBQU1BOzs7Ozs7Ozs7OztBQUduQjtBQUVBLGlFQUFlQyxPQUFPQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dHByb2plY3QvLi9sYXlvdXQvd3JhcHBlci9XcmFwcGVyLmpzeD8wZDA0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi4vaGVhZGVyXCI7XHJcbmltcG9ydCBGb290ZXIgZnJvbSBcIi4uL2Zvb3RlclwiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgICAgPEhlYWRlciAvPiBcclxuICAgICAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+e2NoaWxkcmVufTwvbWFpbj5cclxuICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFdyYXBwZXI7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkhlYWRlciIsIkZvb3RlciIsIldyYXBwZXIiLCJjaGlsZHJlbiIsImRpdiIsImNsYXNzTmFtZSIsIm1haW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./layout/wrapper/Wrapper.jsx\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _layout_wrapper_Wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/layout/wrapper/Wrapper */ \"./layout/wrapper/Wrapper.jsx\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tanstack/react-query */ \"@tanstack/react-query\");\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _styles_carousel_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/carousel.css */ \"./styles/carousel.css\");\n/* harmony import */ var _styles_carousel_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_carousel_css__WEBPACK_IMPORTED_MODULE_6__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_wrapper_Wrapper__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__]);\n([_layout_wrapper_Wrapper__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nconst queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient();\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClientProvider, {\n            client: queryClient,\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_layout_wrapper_Wrapper__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                        ...pageProps\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\pages\\\\_app.js\",\n                        lineNumber: 17,\n                        columnNumber: 21\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {}, void 0, false, {\n                        fileName: \"C:\\\\Project3\\\\nextproject\\\\pages\\\\_app.js\",\n                        lineNumber: 18,\n                        columnNumber: 21\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Project3\\\\nextproject\\\\pages\\\\_app.js\",\n                lineNumber: 16,\n                columnNumber: 17\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Project3\\\\nextproject\\\\pages\\\\_app.js\",\n            lineNumber: 15,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Project3\\\\nextproject\\\\pages\\\\_app.js\",\n        lineNumber: 14,\n        columnNumber: 9\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBK0M7QUFDakI7QUFDMkM7QUFDekI7QUFDRDtBQUNoQjtBQUNDO0FBR2hDLE1BQU1JLGNBQWMsSUFBSUgsOERBQVdBO0FBRXBCLFNBQVNJLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDaEQscUJBQ0ksOERBQUNDO2tCQUNHLDRFQUFDTixzRUFBbUJBO1lBQUNPLFFBQVFMO3NCQUN6Qiw0RUFBQ0osK0RBQU9BOztrQ0FDSiw4REFBQ007d0JBQVcsR0FBR0MsU0FBUzs7Ozs7O2tDQUN4Qiw4REFBQ0osMERBQWNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNbkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0cHJvamVjdC8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgV3JhcHBlciBmcm9tIFwiQC9sYXlvdXQvd3JhcHBlci9XcmFwcGVyXCI7XG5pbXBvcnQgXCJAL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCAncmVhY3QtdG9hc3RpZnkvZGlzdC9SZWFjdFRvYXN0aWZ5LmNzcyc7XG5pbXBvcnQgJy4uL3N0eWxlcy9nbG9iYWxzLmNzcyc7XG5pbXBvcnQgXCIuLi9zdHlsZXMvY2Fyb3VzZWwuY3NzXCI7XG5cblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cbiAgICAgICAgICAgICAgICA8V3JhcHBlcj5cbiAgICAgICAgICAgICAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgICAgICAgICAgICAgICA8VG9hc3RDb250YWluZXIgLz5cbiAgICAgICAgICAgICAgICA8L1dyYXBwZXI+XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwibmFtZXMiOlsiV3JhcHBlciIsIlF1ZXJ5Q2xpZW50IiwiUXVlcnlDbGllbnRQcm92aWRlciIsIlRvYXN0Q29udGFpbmVyIiwicXVlcnlDbGllbnQiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJkaXYiLCJjbGllbnQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/carousel.css":
/*!*****************************!*\
  !*** ./styles/carousel.css ***!
  \*****************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/icons-material/Menu":
/*!*******************************************!*\
  !*** external "@mui/icons-material/Menu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ "@mui/material/AppBar":
/*!***************************************!*\
  !*** external "@mui/material/AppBar" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ "@mui/material/Box":
/*!************************************!*\
  !*** external "@mui/material/Box" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ "@mui/material/Button":
/*!***************************************!*\
  !*** external "@mui/material/Button" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ "@mui/material/Container":
/*!******************************************!*\
  !*** external "@mui/material/Container" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Container");

/***/ }),

/***/ "@mui/material/IconButton":
/*!*******************************************!*\
  !*** external "@mui/material/IconButton" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ "@mui/material/Menu":
/*!*************************************!*\
  !*** external "@mui/material/Menu" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Menu");

/***/ }),

/***/ "@mui/material/MenuItem":
/*!*****************************************!*\
  !*** external "@mui/material/MenuItem" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ "@mui/material/Toolbar":
/*!****************************************!*\
  !*** external "@mui/material/Toolbar" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ "@mui/material/Tooltip":
/*!****************************************!*\
  !*** external "@mui/material/Tooltip" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ "@mui/material/Typography":
/*!*******************************************!*\
  !*** external "@mui/material/Typography" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ "@mui/material/utils":
/*!**************************************!*\
  !*** external "@mui/material/utils" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/utils");

/***/ }),

/***/ "@mui/system":
/*!******************************!*\
  !*** external "@mui/system" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ "@mui/system/DefaultPropsProvider":
/*!***************************************************!*\
  !*** external "@mui/system/DefaultPropsProvider" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/DefaultPropsProvider");

/***/ }),

/***/ "@mui/system/InitColorSchemeScript":
/*!****************************************************!*\
  !*** external "@mui/system/InitColorSchemeScript" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/InitColorSchemeScript");

/***/ }),

/***/ "@mui/system/colorManipulator":
/*!***********************************************!*\
  !*** external "@mui/system/colorManipulator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/colorManipulator");

/***/ }),

/***/ "@mui/system/createStyled":
/*!*******************************************!*\
  !*** external "@mui/system/createStyled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createStyled");

/***/ }),

/***/ "@mui/system/createTheme":
/*!******************************************!*\
  !*** external "@mui/system/createTheme" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createTheme");

/***/ }),

/***/ "@mui/system/styleFunctionSx":
/*!**********************************************!*\
  !*** external "@mui/system/styleFunctionSx" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/styleFunctionSx");

/***/ }),

/***/ "@mui/system/useThemeProps":
/*!********************************************!*\
  !*** external "@mui/system/useThemeProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/useThemeProps");

/***/ }),

/***/ "@mui/utils":
/*!*****************************!*\
  !*** external "@mui/utils" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils");

/***/ }),

/***/ "@mui/utils/capitalize":
/*!****************************************!*\
  !*** external "@mui/utils/capitalize" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/capitalize");

/***/ }),

/***/ "@mui/utils/chainPropTypes":
/*!********************************************!*\
  !*** external "@mui/utils/chainPropTypes" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/chainPropTypes");

/***/ }),

/***/ "@mui/utils/composeClasses":
/*!********************************************!*\
  !*** external "@mui/utils/composeClasses" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/composeClasses");

/***/ }),

/***/ "@mui/utils/deepmerge":
/*!***************************************!*\
  !*** external "@mui/utils/deepmerge" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deepmerge");

/***/ }),

/***/ "@mui/utils/elementTypeAcceptingRef":
/*!*****************************************************!*\
  !*** external "@mui/utils/elementTypeAcceptingRef" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementTypeAcceptingRef");

/***/ }),

/***/ "@mui/utils/formatMuiErrorMessage":
/*!***************************************************!*\
  !*** external "@mui/utils/formatMuiErrorMessage" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/formatMuiErrorMessage");

/***/ }),

/***/ "@mui/utils/generateUtilityClass":
/*!**************************************************!*\
  !*** external "@mui/utils/generateUtilityClass" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClass");

/***/ }),

/***/ "@mui/utils/generateUtilityClasses":
/*!****************************************************!*\
  !*** external "@mui/utils/generateUtilityClasses" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClasses");

/***/ }),

/***/ "@mui/utils/refType":
/*!*************************************!*\
  !*** external "@mui/utils/refType" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/refType");

/***/ }),

/***/ "@mui/utils/requirePropFactory":
/*!************************************************!*\
  !*** external "@mui/utils/requirePropFactory" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/requirePropFactory");

/***/ }),

/***/ "@mui/utils/useEventCallback":
/*!**********************************************!*\
  !*** external "@mui/utils/useEventCallback" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEventCallback");

/***/ }),

/***/ "@mui/utils/useForkRef":
/*!****************************************!*\
  !*** external "@mui/utils/useForkRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useForkRef");

/***/ }),

/***/ "@mui/utils/useIsFocusVisible":
/*!***********************************************!*\
  !*** external "@mui/utils/useIsFocusVisible" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useIsFocusVisible");

/***/ }),

/***/ "@mui/utils/useTimeout":
/*!****************************************!*\
  !*** external "@mui/utils/useTimeout" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useTimeout");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("clsx");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-transition-group":
/*!*****************************************!*\
  !*** external "react-transition-group" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "@tanstack/react-query":
/*!****************************************!*\
  !*** external "@tanstack/react-query" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ "react-cookie":
/*!*******************************!*\
  !*** external "react-cookie" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-cookie");;

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/@mui","vendor-chunks/@babel","vendor-chunks/react-toastify"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();
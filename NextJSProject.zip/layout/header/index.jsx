import React, { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import MenuItem from '@mui/material/MenuItem';
import Menu from '@mui/material/Menu';
import Tooltip from '@mui/material/Tooltip';
// import img1 from '../../../Images/download1.jpg';
// import img2 from '../../../Images/download 2.jpg'
import { profile_pic } from '@/api/axios/axios';
import Link from 'next/link';
import { Cookies } from 'react-cookie';

const pages = ['Home','Productlist', 'CreateData', 'ProfileDetail'];
const settings = ['Login','Register'];

export default function Header() {
  const cookie = new Cookies();
  
  const token = cookie.get("token");
  const image = cookie.get("profile_pic");

  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);

  

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  }
  
 
  return (
    <AppBar position="static" sx={{ backgroundColor: 'orangered' }}>
      <Container maxWidth="xl">
        <Toolbar>
        <Box sx={{ flexGrow: 1, display: { lg: 'flex', md: 'flex', xs:'none' } }}>
    
        {/* <img style={{width:"100px", height:"80px",display:{xs:'none', md:'flex'}}} src={img1} alt="" />  */}
        
          <Typography
            variant="h4"
            noWrap
            style={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 300,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
              // marginTop:"30px"
            }}
          >
           
             UniTech
          </Typography>
          </Box>

          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page} onClick={handleCloseNavMenu}>
                 
                  <Typography textAlign="center">
                    <Link href={`/cms/${page.toLowerCase()}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                      {page}
                    </Link>
                  </Typography>
                </MenuItem>
              ))}
            
              
            </Menu>
           
          </Box>
          <Box sx={{ flexGrow: 1, display: { lg: 'none', md: 'none', xs:'block' } }}>
          {/* <img style={{width:"130px", height:"100px"}} src={img1} alt="" /> */}
          </Box>
          <Typography
            variant="h5"
            
            sx={{
              mr: 2,
              display: { xs: 'flex', md: 'none' },
              flexGrow: 1,
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            UniTech
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {pages.map((page) => (
              <Button
                key={page}
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                <Link href={`/cms/${page.toLowerCase()}`} style={{ textDecoration: 'none', color: 'white' }}>
                  {page}
                </Link>
             
              </Button>
            ))}
              
          </Box>

          <Box sx={{ flexGrow: 0 }}>
            <Tooltip title="Open settings">
              <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                {token !== null && token !== undefined ? (<img style={{width:"30px", height:"30px", borderRadius:"100%"}} src={profile_pic(image)}/>) : (<img style={{width:"30px", height:"30px", borderRadius:"100%"}} src= ""/>)}
              </IconButton>
            </Tooltip>
            <Menu
              sx={{ mt: '45px' }}
              id="menu-appbar"
              anchorEl={anchorElUser}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={Boolean(anchorElUser)}
              onClose={handleCloseUserMenu}
            >
                 {settings?.map((setting) => (
                <MenuItem key={setting} onClick={handleCloseUserMenu}>
                  <Typography textAlign="center"> <Link href={`/auth/${setting.toLowerCase()}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                      {setting}
                    </Link>
                  </Typography>
                  
                </MenuItem>
              ))}

            </Menu>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}



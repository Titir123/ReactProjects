import Link from "next/link";

const Footer = () => {
    return (
        <footer>
            
                    © {new Date().getFullYear()} MyApp. All rights reserved.
              
               <br />
                    <Link style={{textDecoration:"none", color:"black"}}
                        href="/privacy-policy"
                      
                    >
                        Privacy Policy
                    </Link>
                    <Link style={{textDecoration:"none", color:"black"}}
                        href="/terms-of-service"
                       
                    >
                        Terms of Service
                    </Link>
             
        </footer>
    );
};

export default Footer;
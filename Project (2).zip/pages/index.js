import Image from "next/image";
import { Inter } from "next/font/google";
import Carousel from 'react-bootstrap/Carousel';
import 'bootstrap/dist/css/bootstrap.min.css';


const inter = Inter({ subsets: ["latin"] });

export default function Home() {
    return (
        <div>
             <Carousel indicators={false} fade={true} interval={3000}>
      <Carousel.Item>
      <img
          className="d-block w-100"
          src="/Images/240_F_336156751_XY1xfHvk9yl44dRS8opQeeexqvsebzby.jpg"  // Replace with your image URL
          alt="Second slide"
          
        />
        <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img
          className="d-block w-100"
          src= "Images/240_F_336156751_XY1xfHvk9yl44dRS8opQeeexqvsebzby.jpg" // Replace with your image URL
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img
          className="d-block w-100"
          src="/Images/240_F_336156751_XY1xfHvk9yl44dRS8opQeeexqvsebzby.jpg" // Replace with your image URL
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
              
           
        </div>
    );
}